/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import database.JDBCUtil;
import java.sql.*;
/**
 *
 * @author Admin
 */
public class TCPServer {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(9900);
        System.out.println("Server is listening on port 9900...");

        while (true) {
            try {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected");
                Thread clientThread = new ClientHandler(clientSocket);
                clientThread.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static class ClientHandler extends Thread {
        private Socket clientSocket;
        private TCPServer server; // Thêm một tham chiếu đến đối tượng TCPServer
        

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
              this.server = server; // Khởi tạo tham chiếu đến đối tượng TCPServer
        }
        

        @Override
        public void run() {
         try {
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            String name = in.readLine();
            String luaChon = in.readLine();

            // Gọi hàm lookupSongInformation và lấy kết quả
            String songInfo = lookupSongInformation(name);
           // String allSongs = server.getAllsongs(); // Gọi phương thức qua đối tượng TCPServer
            //    out.println(allSongs);

            // Trả kết quả về client
            out.println(songInfo);
            out.println("Đây là chọn: " + luaChon);

            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private String lookupSongInformation(String nameMusic) {
         Connection connection = null;
            String songInfo = "Bài hát không tồn tại."; // Mặc định trả về khi không tìm thấy bài hát

            try {
                connection = JDBCUtil.getConnection();
                if (connection != null) {
                    String query = "SELECT idMusic, nameMusic, lyrics, linkMusic FROM music WHERE nameMusic = ?";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, nameMusic);

                    ResultSet resultSet = preparedStatement.executeQuery();
                    if (resultSet.next()) {
                        // Tìm thấy bài hát
                         String idMusic = resultSet.getString("idMusic");
                         String name = resultSet.getString("nameMusic");
                         String lyrics = resultSet.getString("lyrics");
                         String linkMusic = resultSet.getString("linkMusic");
                         songInfo = "ID Bài Hát: " + idMusic + "\nTên Bài Hát: " + nameMusic + "\nThể Loại: " + lyrics + "\nLink Bài Hát: " + linkMusic;
                    }

                    resultSet.close();
                    preparedStatement.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                JDBCUtil.closeConnection(connection);
            }

            return songInfo;
        }
    }
    private String getAllsongs() {
    Connection connection = null;
    StringBuilder songInfo = new StringBuilder("Danh sách các bài hát:\n");

    try {
        connection = JDBCUtil.getConnection();
        if (connection != null) {
            String query = "SELECT idMusic, nameMusic, lyrics, linkMusic FROM music";
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                // Lặp qua tất cả các bài hát và thêm thông tin vào chuỗi
                String idMusic = resultSet.getString("idMusic");
                String nameMusic = resultSet.getString("nameMusic");
                String lyrics = resultSet.getString("lyrics");
                String linkMusic = resultSet.getString("linkMusic");
                songInfo.append("ID Bài Hát: ").append(idMusic).append("\nTên Bài Hát: ").append(nameMusic)
                        .append("\nThể Loại: ").append(lyrics).append("\nLink Bài Hát: ").append(linkMusic)
                        .append("\n----------------\n");
            }

            resultSet.close();
            preparedStatement.close();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        JDBCUtil.closeConnection(connection);
    }

    return songInfo.toString();
}

    
}

