/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;

/**
 *
 * @author Admin
 */
public class JDBCUtil {
   public static Connection getConnection() {
         Connection c = null;
             try {
        // Đăng ký MySQL Driver với DriverManager
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                // Các thông số
                String url = "jdbc:mySQL://localhost:8111/searchmusic";
                String userName = "root";
                String password = "";
                // Tạo kết nối 
                c = DriverManager.getConnection(url, userName, password);
                System.out.println("Kết nối đến cơ sở dữ liệu thành công");
            } catch (Exception e) {
                System.out.println("Lỗi: Không thể kết nối đến cơ sở dữ liệu");
                e.printStackTrace();
            }
            return c;
}
	public static void closeConnection(Connection c) {
		try {
			if(c!=null) {
				c.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public static void printInfo(Connection c) {
		try {
			if (c != null) {
				DatabaseMetaData mtdt = c.getMetaData();
				System.out.println(mtdt.getDatabaseProductName());
				System.out.println(mtdt.getDatabaseProductVersion());
			} 
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
